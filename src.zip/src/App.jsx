import React, { useState, useEffect, useRef, useMemo } from 'react';
import LifeOSAreasView from './LifeOSAreasView';
import CalendarGridView from './CalendarGridView';
import { 
  CheckCircle, Circle, Plus, Calendar, Clock, Award, Compass, 
  BarChart2, Zap, Brain, MessageSquare, Flame, CheckSquare, 
  ChevronRight, Play, Square, RefreshCw, Layers, Sliders, 
  Settings, Search, Bell, BellRing, Sparkles, Smile, Sun, Moon, ArrowRight,
  TrendingUp, Activity, Check, ChevronDown, User, Volume2, Mic, Trash2, Edit2, AlertCircle, Eye,
  Heart, Shield, Users, SlidersHorizontal, Briefcase, GraduationCap, DollarSign, CalendarRange,
  Lock, Database, Code, Copy, ExternalLink, X, Cloud
} from 'lucide-react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AuthPage from './AuthPage';

// Secure, production-ready non-streaming prompt handler with exponential backoff.
async function callGemini(userPrompt, systemPrompt = "", isJson = false) {
  const apiKey = "";
  // Canvas runtime automatically injects the active workspace key here
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;

  const payload = {
    contents: [{ parts: [{ text: userPrompt }] }],
    systemInstruction: {
      parts: [{ text: systemPrompt }]
    }
  };

  if (isJson) {
    payload.generationConfig = {
      responseMimeType: "application/json"
    };
  }

  let delay = 1000;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        if (response.status === 429) {
          await new Promise(resolve => setTimeout(resolve, delay));
          delay *= 2;
          continue;
        }
        throw new Error(`API Error: ${response.statusText}`);
      }
      const data = await response.json();
      return data.candidates?.[0]?.content?.parts?.[0]?.text || "";

    } catch (error) {
      if (attempt === 2) throw error;
      await new Promise(resolve => setTimeout(resolve, delay));
      delay *= 2;
    }
  }
  return "";
}

const DATABASE_SCHEMAS = {
  prisma: `// Prisma Schema for LifeFlow AI Enterprise Stack
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model User {
  id            String          @id @default(uuid())
  email         String          @unique
  name          String?
  createdAt     DateTime        @default(now())
  updatedAt     DateTime        @updatedAt
  onboarded     Boolean         @default(false)
  role          String          @default("professional")
  tasks         Task[]
  habits        Habit[]
  goals         Goal[]
  lifeAreas     LifeArea[]
  focusSessions FocusSession[]
  userSettings  UserSettings?
}

model Task {
  id          String      @id @default(uuid())
  userId      String
  user        User        @relation(fields: [userId], references: [id], onDelete: Cascade)
  title       String
  date        String
  time        String?
  priority    String      @default("medium")
  category    String      @default("Inbox")
  completed   Boolean     @default(false)
  isRecurring Boolean     @default(false)
  recurrence  String?
  subtasks    Subtask[]
  createdAt   DateTime    @default(now())
}

model Subtask {
  id        String   @id @default(uuid())
  taskId    String
  task      Task     @relation(fields: [taskId], references: [id], onDelete: Cascade)
  text      String
  completed Boolean  @default(false)
}

model Habit {
  id             String   @id @default(uuid())
  userId         String
  user           User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  name           String
  frequency      String   @default("Daily")
  streak         Int      @default(0)
  completedDates String[]
  category       String
  targetTime     String?
}

model Goal {
  id         String      @id @default(uuid())
  userId     String
  user       User        @relation(fields: [userId], references: [id], onDelete: Cascade)
  title      String
  category   String
  targetDate String
  progress   Int         @default(0)
  confidence String      @default("High")
  milestones Milestone[]
}

model Milestone {
  id        String   @id @default(uuid())
  goalId    String
  goal      Goal     @relation(fields: [goalId], references: [id], onDelete: Cascade)
  text      String
  completed Boolean  @default(false)
}

model LifeArea {
  id         String @id @default(uuid())
  userId     String
  user       User   @relation(fields: [userId], references: [id], onDelete: Cascade)
  name       String
  score      Int    @default(50)
  status     String @default("Healthy")
  taskCount  Int    @default(0)
}

model FocusSession {
  id        String   @id @default(uuid())
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  duration  Int
  category  String
  createdAt DateTime @default(now())
}

model UserSettings {
  id            String  @id @default(uuid())
  userId        String  @unique
  user          User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  theme         String  @default("dark")
  gmailSync     Boolean @default(false)
  calendarSync  Boolean @default(false)
  driveSync     Boolean @default(false)
}`,
  sql: `-- PostgreSQL Relational Schema Setup
CREATE TABLE "users" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "email" VARCHAR(255) UNIQUE NOT NULL,
  "name" VARCHAR(255),
  "onboarded" BOOLEAN DEFAULT FALSE,
  "role" VARCHAR(50) DEFAULT 'professional',
  "created_at" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "tasks" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID REFERENCES "users"("id") ON DELETE CASCADE,
  "title" VARCHAR(255) NOT NULL,
  "date" DATE NOT NULL,
  "time" TIME,
  "priority" VARCHAR(20) DEFAULT 'medium',
  "category" VARCHAR(50) DEFAULT 'Inbox',
  "completed" BOOLEAN DEFAULT FALSE,
  "is_recurring" BOOLEAN DEFAULT FALSE,
  "recurrence_pattern" VARCHAR(50)
);

CREATE TABLE "habits" (
  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  "user_id" UUID REFERENCES "users"("id") ON DELETE CASCADE,
  "name" VARCHAR(255) NOT NULL,
  "frequency" VARCHAR(50) DEFAULT 'Daily',
  "streak" INT DEFAULT 0,
  "completed_dates" TEXT[],
  "category" VARCHAR(50) NOT NULL
);`
};

// Global Date Helper to dynamically pull today's date in YYYY-MM-DD
const getTodayStr = () => new Date().toISOString().split('T')[0];

const INITIAL_TASKS = [];
const INITIAL_HABITS = [];
const INITIAL_GOALS = [];

const INITIAL_AREAS = [
  { name: 'Career', score: 0, color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20', lastActive: 'Never', status: 'Pending', taskCount: 0, icon: Briefcase },
  { name: 'Health', score: 0, color: 'text-rose-500 bg-rose-500/10 border-rose-500/20', lastActive: 'Never', status: 'Pending', taskCount: 0, icon: Heart },
  { name: 'Education', score: 0, color: 'text-indigo-500 bg-indigo-500/10 border-indigo-500/20', lastActive: 'Never', status: 'Pending', taskCount: 0, icon: GraduationCap },
  { name: 'Finance', score: 0, color: 'text-amber-500 bg-amber-500/10 border-amber-500/20', lastActive: 'Never', status: 'Pending', taskCount: 0, icon: DollarSign },
  { name: 'Family', score: 0, color: 'text-teal-500 bg-teal-500/10 border-teal-500/20', lastActive: 'Never', status: 'Pending', taskCount: 0, icon: Users },
  { name: 'Personal Growth', score: 0, color: 'text-cyan-500 bg-cyan-500/10 border-cyan-500/20', lastActive: 'Never', status: 'Pending', taskCount: 0, icon: Brain }
];

function LifeFlow() {
  
  const [activeCommandPalette, setActiveCommandPalette] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [theme, setTheme] = useState('dark');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [tasks, setTasks] = useState(INITIAL_TASKS);
  const [habits, setHabits] = useState(INITIAL_HABITS);
  const [goals, setGoals] = useState(INITIAL_GOALS);
  const [lifeAreas, setLifeAreas] = useState(INITIAL_AREAS);
  const [mood, setMood] = useState('Normal'); 
  const [searchQuery, setSearchQuery] = useState('');

  // Custom smart schedule variables
  const [scheduleInputs, setScheduleInputs] = useState({
    workHours: '9:00 - 17:00',
    gymTime: '18:00 - 19:30',
    deadlines: 'Midnight Review',
    energyLevel: 'Normal'
  });
  
  const [generatedSchedule, setGeneratedSchedule] = useState([]);
  const [generatingSchedule, setGeneratingSchedule] = useState(false);

  // Natural Language Task State variables
  const [nlpInput, setNlpInput] = useState('');
  const [nlpParsing, setNlpParsing] = useState(false);
  const [parsedPreview, setParsedPreview] = useState(null);

  // Focus Timer Configurations
  const [focusTime, setFocusTime] = useState(1500);
  const [focusRunning, setFocusRunning] = useState(false);
  const [focusCategory, setFocusCategory] = useState('Coding');
  const [recordedMinutes, setRecordedMinutes] = useState(0);
  const [selectedAmbient, setSelectedAmbient] = useState('Forest Rain Loop');

  // Integrations state configurations
  const [integrationSwitches, setIntegrationSwitches] = useState({
    gmail: false,
    calendar: false,
    drive: false,
    meet: false
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    let interval = null;
    if (focusRunning && focusTime > 0) {
      interval = setInterval(() => {
        setFocusTime(prev => prev - 1);
      }, 1000);
    } else if (focusTime === 0 && focusRunning) {
      setFocusRunning(false);
      setRecordedMinutes(prev => prev + 25);
      triggerToast("🎯 Focus Block Complete!", "Added 25 minutes of highly focused deep work.");
      setFocusTime(1500);
    }
    return () => clearInterval(interval);
  }, [focusRunning, focusTime]);

  // Adjusted to allow dynamic custom lifetimes for reminders
  const triggerToast = (title, message = "", type = "Success", duration = 4000) => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, duration);
  };

  // Global Notification Engine for Habits and Tasks
  useEffect(() => {
    const checkTaskTimes = setInterval(() => {
      const now = new Date();
      // Use HH:MM format for direct string comparison against targetTime / completionTime
      const currentHoursMinutes = now.toTimeString().slice(0, 5); 

      // Setup 5-minute and 10-minute lookahead timestamps
      const in5Min = new Date(now.getTime() + 5 * 60 * 1000);
      const in5MinHHMM = in5Min.toTimeString().slice(0, 5);

      const in10Min = new Date(now.getTime() + 10 * 60 * 1000);
      const in10MinHHMM = in10Min.toTimeString().slice(0, 5);

      // 1. Habit Loops Logic (Routine alarms + pre-reminders)
      setHabits(prevHabits => {
        let isUpdated = false;
        const nextHabits = prevHabits.map(habit => {
          let updatedHabit = { ...habit };

          // 10 Minutes Reminder Check
          if (habit.targetTime === in10MinHHMM && !habit.notified10) {
            triggerToast("Habit Reminder", `REMINDER: ${habit.name} nee to be completed in 10 minutes.`, "info", 10000);
            updatedHabit.notified10 = true;
            isUpdated = true;
          } else if (habit.targetTime !== in10MinHHMM && habit.notified10) {
            updatedHabit.notified10 = false;
            isUpdated = true;
          }

          // 5 Minutes Reminder Check
          if (habit.targetTime === in5MinHHMM && !habit.notified5) {
            triggerToast("Habit Reminder", `REMINDER: ${habit.name} nee to be completed in 5 minutes.`, "info", 10000);
            updatedHabit.notified5 = true;
            isUpdated = true;
          } else if (habit.targetTime !== in5MinHHMM && habit.notified5) {
            updatedHabit.notified5 = false;
            isUpdated = true;
          }

          // Target Deadline/Completion Reached Alarm Sound Module
          if (habit.targetTime === currentHoursMinutes && !habit.notified) {
            const alarmAudio = new Audio('/alarm-sound.mp3');
            alarmAudio.play().catch(err => console.error("Audio blocked:", err));

            triggerToast("Routine Alert", `complete the routine: ${habit.name}`, "alarm", 10000);
            updatedHabit.notified = true;
            isUpdated = true;
          } else if (habit.targetTime !== currentHoursMinutes && habit.notified) {
            updatedHabit.notified = false;
            isUpdated = true;
          }

          return updatedHabit;
        });
        return isUpdated ? nextHabits : prevHabits;
      });

      // 2. General Tasks Logic (MyDay, TaskHubs, LifeOS)
      setTasks(prevTasks => {
        let isUpdated = false;
        const nextTasks = prevTasks.map(task => {
          const taskTime = task.completionTime || task.time;
          if (!taskTime) return task;

          let updatedTask = { ...task };

          // 10 Minutes Reminder Check
          if (!task.completed && taskTime === in10MinHHMM && !task.notified10) {
            triggerToast("Task Reminder", `REMINDER: ${task.title} nee to be completed in 10 minutes.`, "info", 10000);
            updatedTask.notified10 = true;
            isUpdated = true;
          } else if (taskTime !== in10MinHHMM && task.notified10) {
            updatedTask.notified10 = false;
            isUpdated = true;
          }

          // 5 Minutes Reminder Check
          if (!task.completed && taskTime === in5MinHHMM && !task.notified5) {
            triggerToast("Task Reminder", `REMINDER: ${task.title} nee to be completed in 5 minutes.`, "info", 10000);
            updatedTask.notified5 = true;
            isUpdated = true;
          } else if (taskTime !== in5MinHHMM && task.notified5) {
            updatedTask.notified5 = false;
            isUpdated = true;
          }

          // Main Target Time Reached
          if (!task.completed && taskTime === currentHoursMinutes && !task.notified) {
            triggerToast(
              "Task Deadline", 
              `the completion time of this task has been arrived: ${task.title}`, 
              "info",
              10000
            );
            updatedTask.notified = true;
            isUpdated = true;
          } else if (taskTime !== currentHoursMinutes && task.notified) {
            updatedTask.notified = false;
            isUpdated = true;
          }

          return updatedTask;
        });
        return isUpdated ? nextTasks : prevTasks;
      });

    }, 10000); // Check safely every 10 seconds

    return () => clearInterval(checkTaskTimes);
  }, []); 

  const processLiveNlpHeuristics = (input) => {
    if (!input.trim()) {
      setParsedPreview(null);
      return;
    }
    const val = input.toLowerCase();
    const preview = {
      title: input,
      date: 'Today',
      time: '12:00',
      priority: 'medium',
      category: 'Inbox',
      isRecurring: false
    };

    if (val.includes('tomorrow')) preview.date = 'Tomorrow';
    else if (val.includes('friday')) preview.date = 'Friday';
    else if (val.includes('monday')) preview.date = 'Monday';

    if (val.includes('every day') || val.includes('every week') || val.includes('monthly')) {
      preview.isRecurring = true;
    }

    if (val.includes('high priority') || val.includes('!!!') || val.includes('urgent')) {
      preview.priority = 'high';
    } else if (val.includes('low priority') || val.includes('easy')) {
      preview.priority = 'low';
    }

    const matchedCat = ['Career', 'Health', 'Education', 'Finance', 'Personal Growth', 'Family'].find(
      cat => val.includes(cat.toLowerCase())
    );

    if (matchedCat) preview.category = matchedCat;

    setParsedPreview(preview);
  };

  const handleSmartTaskSubmit = async (e) => {
    e.preventDefault();
    if (!nlpInput.trim()) return;
    setNlpParsing(true);

    let finalTask = {
      id: 'task_' + Date.now(),
      title: nlpInput,
      date: getTodayStr(),
      time: '12:00',
      priority: 'medium',
      category: 'Inbox',
      completed: false,
      subtasks: []
    };

    try {
      const systemPrompt = `You are LifeFlow AI's natural language productivity engine.
      Analyze the user prompt. Extract task parameters relative to today (${getTodayStr()}).
      Respond with structured JSON ONLY.
      Schema:
      {
        "title": "Cleaned task name (no date words)",
        "date": "YYYY-MM-DD",
        "time": "HH:MM",
        "priority": "high" | "medium" | "low",
        "category": "Career" | "Health" | "Education" | "Finance" | "Family" | "Personal Growth" | "Inbox",
        "subtasks": ["subtask 1", "subtask 2"]
      }`;

      const response = await callGemini(`Parse task input: "${nlpInput}"`, systemPrompt, true);

      if (response) {
        const data = JSON.parse(response);
        finalTask = {
          ...finalTask,
          title: data.title || finalTask.title,
          date: data.date || finalTask.date,
          time: data.time || finalTask.time,
          priority: data.priority || finalTask.priority,
          category: data.category || finalTask.category,
          subtasks: data.subtasks || []
        };
      }
    } catch (error) {
      console.warn("Falling back to client regex parsing:", error);
      if (parsedPreview) {
        const offsetDateStr = (days) => {
          const d = new Date();
          d.setDate(d.getDate() + days);
          return d.toISOString().split('T')[0];
        };

        finalTask = {
          ...finalTask,
          title: parsedPreview.title,
          date: parsedPreview.date === 'Today' ? getTodayStr() : parsedPreview.date === 'Tomorrow' ? offsetDateStr(1) : offsetDateStr(2),
          priority: parsedPreview.priority,
          category: parsedPreview.category
        };
      }
    }

    setTasks(prev => [finalTask, ...prev]);
    triggerToast("Task Created", `"${finalTask.title}" allocated to ${finalTask.category}`);
    setNlpInput('');
    setParsedPreview(null);
    setNlpParsing(false);
  };

  const toggleTask = (id) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const nextState = !t.completed;
        if (nextState) {
          triggerToast("🚀 Daily Flow Upgraded!", "+10 productivity score coordinates registered.");
        }
        return { ...t, completed: nextState };
      }
      return t;
    }));
  };

  const handleHabitToggle = (habitId, dateStr = getTodayStr()) => {
    setHabits(prev => prev.map(h => {
      if (h.id === habitId) {
        const isLogged = h.completedDates.includes(dateStr);
        let updatedDates = [...h.completedDates];
        let streakDelta = h.streak;

        if (isLogged) {
          updatedDates = updatedDates.filter(d => d !== dateStr);
          streakDelta = Math.max(0, streakDelta - 1);
        } else {
          updatedDates.push(dateStr);
          streakDelta += 1;
        }
        return { ...h, completedDates: updatedDates, streak: streakDelta, missedStreak: false };
      }
      return h;
    }));
    triggerToast("Routine Logged", "Consistency metrics synchronized across Life OS.");
  };

  const moodAdaptedTasks = useMemo(() => {
    return tasks.filter(t => {
      if (mood === 'Tired') {
        return t.priority === 'low' || t.priority === 'medium';
      }
      if (mood === 'Energetic') {
        return t.priority === 'high' || t.priority === 'medium';
      }
      return true;
    });
  }, [tasks, mood]);

  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState({
    name: "Julien Daniels",
    role: "Core Stack Dev"
  });

  return (
    <div className={`min-h-screen font-sans antialiased selection:bg-emerald-500/35 transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#080d16]' : 'bg-[#f8fafc]'
    }`}>
      
      {/* Dynamic Overlay Notification Center */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full pointer-events-none">
          {toasts.map(toast => {
          const isAlarm = toast.type === 'alarm';
      
          return (
            <div 
              key={toast.id} 
              className={`p-4 rounded-xl shadow-2xl border backdrop-blur-md transition-all duration-300 pointer-events-auto flex gap-3 transform scale-100 ${
                theme === 'dark' 
                  ? isAlarm ? 'bg-red-950/90 border-red-500/50 text-slate-100' : 'bg-[#0f172a]/95 border-emerald-500/20 text-slate-100' 
                  : isAlarm ? 'bg-red-50/95 border-red-500/50 text-slate-900' : 'bg-white/95 border-emerald-500/20 text-slate-900'
              }`}
            >
              <div className="flex-shrink-0">
                {isAlarm ? (
                  <BellRing className="w-5 h-5 text-red-400 animate-[bounce_1s_infinite]" />
                ) : (
                  <Sparkles className="w-5 h-5 text-emerald-400 animate-pulse" />
                )}
              </div>
              <div className="flex-1">
                <h4 className={`text-xs font-bold font-mono tracking-wide uppercase ${isAlarm ? 'text-red-400' : 'text-emerald-400'}`}>
                  {toast.title}
                </h4>
                {toast.message && (
                  <p className="text-[11px] text-slate-400 dark:text-slate-400 mt-1">
                    {toast.message}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Global Command Palette Dialog */}
      {activeCommandPalette && (
        <CommandPalette onClose={() => setActiveCommandPalette(false)} onSelectView={(view) => { setActiveTab(view); setActiveCommandPalette(false); }} />
      )}

      {/* Application Onboarding Setup Overlay */}
      {showOnboarding && (
        <OnboardingOverlay 
          theme={theme} 
          onClose={() => {
            setShowOnboarding(false);
            triggerToast("Onboarding Optimized", "Personalized deep productivity matrices fully established.", "Success");
          }} 
        />
      )}

      {/* Structured Dual-Pane App Layout */}
      <div className="flex min-h-screen">
        
        {/* LEFT COMPACT NAVIGATION SIDEBAR */}
        <aside className={`fixed lg:sticky top-0 left-0 h-screen w-64 flex flex-col border-r z-40 transition-all ${
          theme === 'dark' ? 'bg-[#0b1322] border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="p-5 flex items-center justify-between border-b dark:border-slate-800/60">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <h1 className="font-extrabold text-sm tracking-tight  text-white">LifeFlow AI</h1>
                <p className="text-[9px] text-emerald-400 font-mono tracking-wider uppercase font-semibold">Plan less. Achieve more.</p>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 px-3 block mb-2 font-mono">Workspace Views</span>
              <nav className="space-y-1">
                <SidebarItem icon={<Layers className="w-4 h-4" />} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
                <SidebarItem icon={<Compass className="w-4 h-4" />} label="My Day" active={activeTab === 'myday'} onClick={() => setActiveTab('myday')} badge="Focus" />
                <SidebarItem icon={<CheckSquare className="w-4 h-4" />} label="Tasks Hub" active={activeTab === 'tasks'} onClick={() => setActiveTab('tasks')} badge={tasks.filter(t => !t.completed).length} />
                <SidebarItem icon={<CalendarRange className="w-4 h-4" />} label="Calendar Grid" active={activeTab === 'calendar'} onClick={() => setActiveTab('calendar')} />
              </nav>
            </div>

            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 px-3 block mb-2 font-mono">Systems</span>
              <nav className="space-y-1">
                <SidebarItem icon={<Flame className="w-4 h-4" />} label="Habits Loop" active={activeTab === 'habits'} onClick={() => setActiveTab('habits')} badge="Routines" />
                <SidebarItem icon={<Award className="w-4 h-4" />} label="Goals Roadmap" active={activeTab === 'goals'} onClick={() => setActiveTab('goals')} />
                <SidebarItem icon={<Brain className="w-4 h-4" />} label="Focus Ambient" active={activeTab === 'focus'} onClick={() => setActiveTab('focus')} badge="Timer" />
                <SidebarItem icon={<Activity className="w-4 h-4" />} label="Life OS Areas" active={activeTab === 'areas'} onClick={() => setActiveTab('areas')} />
              </nav>
            </div>
          </div>

          <div className="p-4 border-t dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-slate-800 border dark:border-slate-700 flex items-center justify-center font-bold text-xs text-emerald-400 font-mono">
                JD
              </div>
              <div>
                <h4 className="text-xs font-bold">Julien Daniels</h4>
                <p className="text-[10px] text-slate-400 font-mono">Core Stack Dev</p>
              </div>
            </div>
            <button 
              onClick={() => setShowOnboarding(true)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              title="Reset System Onboarding"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </aside>

        {/* MAIN INTEGRATED VIEWPORT CONTAINER */}
        <main className="flex-1 min-w-0 flex flex-col min-h-screen">
          
          {/* TOP BAR MANAGEMENT INTERFACE */}
          <header className={`sticky top-0 z-30 flex items-center justify-between px-6 py-4 border-b backdrop-blur-md ${
            theme === 'dark' ? 'bg-[#080d16]/80 border-slate-800/60' : 'bg-[#f8fafc]/80 border-slate-200'
          }`}>
            <div className="flex items-center gap-4 flex-1">
              <div className="relative w-80 max-w-sm hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Universal search (Press Ctrl+K)..."
                  className={`w-full pl-9 pr-4 py-1.5 rounded-xl text-xs outline-none border transition-all ${
                    theme === 'dark' ? 'bg-[#0c1220] border-slate-800 text-slate-200 focus:border-slate-700' : 'bg-white border-slate-200 text-slate-800 focus:border-slate-400'
                  }`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                
                {/* Dynamic Search Results Dropdown */}
                {searchQuery && (
                  <div className={`absolute top-full left-0 mt-2 w-full rounded-xl border shadow-2xl p-2 z-50 ${
                    theme === 'dark' ? 'bg-[#0b1322] border-slate-800' : 'bg-white border-slate-200'
                  }`}>
                    <div className="text-[9px] font-bold uppercase tracking-widest text-slate-500 mb-2 px-2">Tasks Found</div>
                    {tasks.filter(t => t.title.toLowerCase().includes(searchQuery.toLowerCase())).length === 0 ? (
                      <div className="p-2 text-xs text-slate-500 text-center">No matching tasks found.</div>
                    ) : (
                      tasks.filter(t => t.title.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 5).map(t => (
                        <div 
                          key={t.id} 
                          className={`p-2 rounded-lg text-xs cursor-pointer transition-all flex items-center justify-between ${
                            theme === 'dark' ? 'hover:bg-slate-800 text-slate-200' : 'hover:bg-slate-100 text-slate-800'
                          }`}
                          onClick={() => { setActiveTab('tasks'); setSearchQuery(''); }}
                        >
                          <span className="truncate">{t.title}</span>
                          <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded font-mono border border-emerald-500/20">{t.category}</span>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
              
              {/* Dynamic Workspace State Pill */}
              <div className="flex items-center gap-2 border dark:border-slate-800 bg-slate-100 dark:bg-slate-900/60 p-1 rounded-xl">
                {['Energetic', 'Normal', 'Tired'].map(lvl => (
                  <button 
                    key={lvl}
                    onClick={() => {
                      setMood(lvl);
                      triggerToast(`Mood: ${lvl}`, `Optimizing tasks and system recommendation parameters for your energy.`, "Info");
                    }}
                    className={`px-3 py-1 text-[10px] font-bold uppercase rounded-lg transition-all ${
                      mood === lvl ? 'bg-emerald-500 text-[#080d16]' : 'text-slate-400'
                    }`}
                  >
                    {lvl === 'Energetic' ? '⚡ Energetic' : lvl === 'Tired' ? '🔋 Tired' : 'Balanced'}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick-stats & Theme Controls */}
            <div className="flex items-center gap-3">
              
              {/* Gamification Level & Streak Trackers */}
              <div className="flex items-center gap-3 bg-slate-900/40 border dark:border-slate-800/80 px-3 py-1 rounded-xl text-xs font-mono">
                <div className="flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 text-orange-500 animate-pulse" />
                  <span className="text-orange-500 font-bold">
                    {habits.reduce((acc, h) => acc + h.streak, 0)} Days
                  </span>
                </div>
                <div className="w-px h-3 bg-slate-800" />
                <div className="flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-slate-300 font-bold">LVL 1</span>
                </div>
              </div>

              {/* Theme Toggle */}
              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className={`p-2 rounded-xl border transition-all ${
                  theme === 'dark' ? 'bg-[#0c1220] border-slate-800 text-amber-400 hover:border-slate-700' : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
                title="Toggle System Theme"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              {/* Inbox Bell Notifications */}
              <button 
                onClick={() => triggerToast("Activity Report Sync", "Systems metrics calibrated and locked-in for today.")}
                className="p-2 rounded-xl border dark:border-slate-800 text-slate-400 relative"
              >
                <Bell className="w-4 h-4" />
                {tasks.filter(t => !t.completed).length > 0 && <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-rose-500 rounded-full animate-ping"></span>}
              </button>

              <button 
                onClick={() => setActiveTab('tasks')}
                className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] font-extrabold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-lg shadow-emerald-500/10 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add Task</span>
              </button>
            </div>
          </header>

          {/* DYNAMIC SCREEN WORKSPACE ROUTER */}
          <div className="flex-1 p-6 space-y-6 overflow-y-auto">
            <div className={`p-4 rounded-2xl border transition-all ${
              theme === 'dark' ? 'bg-[#0b1322] border-slate-800/80' : 'bg-white border-slate-200'
            }`}>
              <form onSubmit={handleSmartTaskSubmit} className="flex gap-3 items-center">
                {/* Intentional space for parsing triggers if desired */}
              </form>
            </div>

            {activeTab === 'dashboard' && (
              <DashboardView 
                theme={theme} 
                tasks={tasks} 
                habits={habits} 
                goals={goals} 
                toggleTask={toggleTask} 
                handleHabitToggle={handleHabitToggle} 
                mood={mood} 
                setActiveTab={setActiveTab} 
              />
            )}

            {activeTab === 'myday' && (
              <MyDayView 
                theme={theme} 
                tasks={moodAdaptedTasks} 
                habits={habits} 
                toggleTask={toggleTask} 
                handleHabitToggle={handleHabitToggle} 
                mood={mood} 
                triggerToast={triggerToast} 
              />
            )}

            {activeTab === 'tasks' && (
              <TasksHubView 
                theme={theme} 
                tasks={tasks} 
                setTasks={setTasks} 
                toggleTask={toggleTask} 
                triggerToast={triggerToast} 
              />
            )}

            {activeTab === 'calendar' && (
              <CalendarGridView 
                theme={theme} 
                tasks={tasks} 
                setTasks={setTasks} 
                triggerToast={triggerToast} 
              />
            )}

            {activeTab === 'habits' && (
              <HabitsLoopView 
                theme={theme} 
                habits={habits} 
                setHabits={setHabits} 
                handleHabitToggle={handleHabitToggle} 
                triggerToast={triggerToast} 
              />
            )}

            {activeTab === 'goals' && (
              <GoalsRoadmapView 
                theme={theme} 
                goals={goals} 
                setGoals={setGoals} 
                triggerToast={triggerToast} 
              />
            )}

            {activeTab === 'focus' && (
              <FocusAmbientView 
                theme={theme} 
                focusTime={focusTime} 
                setFocusTime={setFocusTime} 
                focusRunning={focusRunning} 
                setFocusRunning={setFocusRunning} 
                focusCategory={focusCategory} 
                setFocusCategory={setFocusCategory} 
                recordedMinutes={recordedMinutes} 
                selectedAmbient={selectedAmbient} 
                setSelectedAmbient={setSelectedAmbient} 
              />
            )}

            {activeTab === 'areas' && (
              <LifeOSAreasView 
                theme={theme} 
                tasks={tasks}
                setTasks={setTasks}
                habits={habits}            
                setHabits={setHabits}      
                handleHabitToggle={handleHabitToggle} 
              />
            )}

          </div>
        </main>
      </div>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick, badge }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold tracking-tight transition-all ${
        active 
          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10 font-bold' 
          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/20'
      }`}
    >
      <div className="flex items-center gap-2.5">
        <span className={active ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}>{icon}</span>
        <span>{label}</span>
      </div>
      {badge !== undefined && (
        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded font-mono ${
          active ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800/60 text-slate-500'
        }`}>
          {badge}
        </span>
      )}
    </button>
  );
}

function DashboardView({ theme, tasks, habits, goals, toggleTask, handleHabitToggle, mood, setActiveTab }) {
  const pendingCount = tasks.filter(t => !t.completed).length;
  const flowAccuracy = useMemo(() => {
    const total = tasks.length;
    const completed = tasks.filter(t => t.completed).length;
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  }, [tasks]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fadeIn">
      <div className="lg:col-span-2 space-y-6">
        <div className="relative overflow-hidden p-6 rounded-3xl border dark:border-slate-800 bg-gradient-to-br from-[#0c1322] to-[#080d16]">
          <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <span className="text-[10px] tracking-widest font-bold uppercase text-emerald-400 font-mono">FLOW LEVEL PARADIGM</span>
              <h2 className="text-xl font-extrabold tracking-tight text-white mt-1">Sustained Workspace Consistency</h2>
              <p className="text-xs text-slate-400 mt-1 max-w-sm">
                You have logged <strong className="text-slate-100">{pendingCount} critical action items</strong> pending today's energy blocks.
              </p>
            </div>
            
            <div className="flex items-center gap-3.5 bg-[#080d16]/80 p-3.5 rounded-2xl border dark:border-slate-800/80">
              <div className="relative w-12 h-12 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="24" cy="24" r="20" fill="transparent" stroke="#1e293b" strokeWidth="4" />
                  <circle cx="24" cy="24" r="20" fill="transparent" stroke="#10b981" strokeWidth="4" 
                    strokeDasharray={2 * Math.PI * 20}
                    strokeDashoffset={2 * Math.PI * 20 * (1 - flowAccuracy / 100)}
                    className="transition-all duration-700"
                  />
                </svg>
                <span className="absolute text-[10px] font-mono font-bold text-slate-100">{flowAccuracy}%</span>
              </div>
              <div>
                <h4 className="text-[9px] uppercase font-bold tracking-wider text-slate-500 font-mono">FLOW SCORE</h4>
                <p className="text-xs font-semibold text-slate-300">Leveling Up Sequence</p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.02] flex flex-col md:flex-row justify-between items-start md:items-center gap-3 animate-pulse">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div>
              <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest font-mono">AI PRIORITY SUGGESTION</span>
              <p className="text-xs font-semibold text-slate-200 mt-0.5">Focus on alignment goals and initiate primary tasks based on today's energy constraints.</p>
            </div>
          </div>
          <button 
            onClick={() => setActiveTab('myday')}
            className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] font-bold text-[10px] uppercase tracking-wide px-3 py-1.5 rounded-lg"
          >
            Go to My Day
          </button>
        </div>

        <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322]">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-xs font-bold uppercase text-slate-400 font-mono">Today's Focus Core</h3>
              <p className="text-[10px] text-slate-500">Structured tasks and deadlines for {getTodayStr()}</p>
            </div>
            <button 
              onClick={() => setActiveTab('tasks')}
              className="text-[10px] font-semibold text-emerald-400 hover:underline font-mono"
            >
              See Inbox ({tasks.length})
            </button>
          </div>

          <div className="space-y-2.5">
            {tasks.length === 0 ? (
                <div className="py-6 text-center text-slate-500 text-xs">No active tasks logged yet. Create a task to start leveling up.</div>
            ) : (
                tasks.slice(0, 4).map(t => (
                <TaskCard key={t.id} task={t} onToggle={toggleTask} />
                ))
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Consistency Streak Overview</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400">Level 1 Initiator</span>
              <span className="font-mono text-emerald-400 font-bold">{tasks.filter(t => t.completed).length * 10} / 500 XP</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${Math.min(((tasks.filter(t => t.completed).length * 10) / 500) * 100, 100)}%` }} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2">
            <div className="p-3 bg-[#080d16] rounded-xl border dark:border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase font-mono block">Weekly Accuracy</span>
              <span className="text-xs font-bold text-slate-200">{flowAccuracy}%</span>
            </div>
            <div className="p-3 bg-[#080d16] rounded-xl border dark:border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase font-mono block">Focus Sessions</span>
              <span className="text-xs font-bold text-slate-200">{tasks.filter(t => t.completed).length} items</span>
            </div>
          </div>
        </div>

        <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Goal Roadmaps</h3>
            <button onClick={() => setActiveTab('goals')} className="text-[10px] text-emerald-400 hover:underline">All Goals</button>
          </div>

          <div className="space-y-2">
            {goals.length === 0 ? (
                 <div className="py-6 text-center text-slate-500 text-xs">No active goals. Set a target roadmap.</div>
            ) : (
                goals.map(g => (
                <div key={g.id} className="p-3 rounded-xl bg-[#080d16] border dark:border-slate-800/80 space-y-2">
                    <div className="flex justify-between text-xs">
                    <span className="font-semibold truncate max-w-[150px]">{g.title}</span>
                    <span className="font-mono text-emerald-400">{g.progress}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${g.progress}%` }} />
                    </div>
                </div>
                ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function MyDayView({ theme, tasks, habits, toggleTask, handleHabitToggle, mood, triggerToast }) {
  const [morningNotes, setMorningNotes] = useState('');
  const [plannerChecked, setPlannerChecked] = useState(false);

  const todayTasks = tasks.filter(t => t.date === getTodayStr());
  
  const missedHabitAlert = useMemo(() => {
    return habits.find(h => h.missedStreak);
  }, [habits]);

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight text-white">My Day</h2>
          <p className="text-xs text-slate-400">Structured flow control and priority alignment for {getTodayStr()}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-5">
          {missedHabitAlert && (
            <div className="p-4 rounded-2xl border border-rose-500/20 bg-rose-500/[0.02] flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5 animate-bounce" />
                <div>
                  <h4 className="text-xs font-bold text-rose-400 uppercase tracking-widest font-mono">HABIT RECOVERY MATRIX ACTIVE</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Streak lapsed for: <strong>{missedHabitAlert.name}</strong>. Let's do a micro 15-minute reduced session today to maintain flow structure!
                  </p>
                </div>
              </div>
              <button 
                onClick={() => {
                  handleHabitToggle(missedHabitAlert.id);
                  triggerToast("Habit Restored", "Recovery routine completed successfully. Streak protection secured.");
                }}
                className="bg-rose-500 hover:bg-rose-600 text-white font-bold text-[10px] uppercase px-3.5 py-1.5 rounded-lg flex-shrink-0"
              >
                Log Recovery Session
              </button>
            </div>
          )}

          <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Morning Alignment Declaration</h3>
            <textarea 
              rows="2"
              placeholder="What represents your absolute core focus directive today?"
              className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl p-3 text-xs outline-none focus:border-slate-700 resize-none"
              value={morningNotes}
              onChange={(e) => setMorningNotes(e.target.value)}
            />
            <div className="flex justify-between items-center">
              <span className="text-[10px] text-slate-500">Syncs to calendar notification payloads.</span>
              <button 
                onClick={() => {
                  setPlannerChecked(true);
                  triggerToast("Directives Locked", "Morning objectives successfully synchronized.");
                }}
                className="bg-emerald-500 text-[#080d16] font-bold text-[10px] uppercase px-4 py-1.5 rounded-lg"
              >
                Lock Focus Intent
              </button>
            </div>
          </div>

          <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Today's Executable Blocks</h3>
            <div className="space-y-2">
              {todayTasks.length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-xs">No active goals matching today's mood filter. Change mood level on top bar or add a task.</div>
              ) : (
                todayTasks.map(t => (
                  <TaskCard key={t.id} task={t} onToggle={toggleTask} />
                ))
              )}
            </div>
          </div>
        </div>

        <div className="space-y-5">
          <div className="p-5 rounded-2xl border border-emerald-500/15 bg-gradient-to-br from-[#0c1322] to-[#080d16] space-y-3">
            <div className="flex items-center gap-2 text-emerald-400">
              <Brain className="w-4 h-4 animate-pulse" />
              <h4 className="text-xs font-bold uppercase font-mono tracking-wider">LifeFlow Smart Guard</h4>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Based on your selected <strong className="text-emerald-300 capitalize">{mood}</strong> energy profile, the database has re-organized priority queues.
              Complete administrative items or fast micro-tasks before initiating any heavy engineering.
            </p>
          </div>

          <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold uppercase text-slate-400 font-mono">External Integrations</span>
              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase font-mono">GCal Live</span>
            </div>
            
            <div className="space-y-2">
              <div className="p-2.5 rounded-lg bg-[#080d16] border dark:border-slate-800/60 text-xs flex justify-between items-center">
                <div className="text-slate-500 text-center py-4 w-full text-xs">No external meetings detected today.</div>
                <Cloud className="w-4 h-4 text-emerald-400" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TasksHubView({ theme, tasks, setTasks, toggleTask, triggerToast }) {
  
  const getTodayStr = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  const categoryFilters = useMemo(() => {
    const defaults = ['All', 'Career', 'Health', 'Education', 'Finance', 'Personal Growth', 'Family'];
    const activeCustomCategories = tasks.map(t => t.category).filter(Boolean);
    return Array.from(new Set([...defaults, ...activeCustomCategories]));
  }, [tasks]);

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [taskName, setTaskName] = useState('');
  const [taskPriority, setTaskPriority] = useState('medium');
  const [taskCategory, setTaskCategory] = useState('Career');
  const [completionTime, setCompletionTime] = useState('17:00');

  const filteredTasks = useMemo(() => {
    if (selectedCategory === 'All') return tasks;
    return tasks.filter(t => t.category === selectedCategory);
  }, [tasks, selectedCategory]);

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (!taskName.trim()) return;

    const timeInstance = new Date();
    const cleanCreationTime = timeInstance.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: true 
    });

    const newTask = {
      id: 'task_' + Date.now(),
      title: taskName,
      date: getTodayStr(), 
      createdAt: cleanCreationTime,
      completionTime: completionTime || '12:00', 
      priority: taskPriority,
      category: taskCategory.trim() || 'General',
      completed: false,
      notified: false,
      notified10: false,
      notified5: false,
      subtasks: []
    };

    setTasks(prev => [newTask, ...prev]);
    triggerToast("Task Created", `"${taskName}" mapped to ${newTask.category}`);
    setTaskName('');
  };

  const removeTask = (id) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    triggerToast("Task Deleted", "Removed item permanently from dashboard pipeline.");
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-xl font-extrabold tracking-tight text-white">Tasks & Inbox Hub</h2>
        <p className="text-xs text-slate-400">Perform direct CRUD operations, filter custom text variables, and register smart task alerts</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="space-y-1.5 max-h-[75vh] overflow-y-auto pr-1">
          {categoryFilters.map(cat => {
            const count = cat === 'All' ? tasks.length : tasks.filter(t => t.category === cat).length;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`w-full p-3 rounded-xl border text-left flex justify-between items-center text-xs font-semibold tracking-tight transition-all ${
                  selectedCategory === cat 
                    ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-400 font-bold' 
                    : 'border-slate-800/80 bg-[#0b1322]/40 hover:bg-[#0b1322] text-slate-400'
                }`}
              >
                <span className="truncate mr-2">{cat}</span>
                <span className="font-mono bg-[#080d16] px-1.5 py-0.5 rounded text-[10px] shrink-0">{count}</span>
              </button>
            );
          })}
        </div>

        <div className="lg:col-span-3 space-y-4">
          <form onSubmit={handleManualSubmit} className="p-4 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
            <div className="flex flex-col gap-3">
              <input 
                type="text" 
                placeholder="What objective or milestone needs recording?"
                className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-3 py-2.5 text-xs outline-none text-slate-100 placeholder:text-slate-600"
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
              />
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
                <select 
                  className="bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 outline-none"
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value)}
                >
                  <option value="high">🛑 High Priority</option>
                  <option value="medium">⚡ Medium Priority</option>
                  <option value="low">☕ Low Priority</option>
                </select>
                
                <div className="relative">
                  <input 
                    list="task-categories-datalist"
                    type="text"
                    placeholder="Type or Select Category"
                    className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 outline-none"
                    value={taskCategory}
                    onChange={(e) => setTaskCategory(e.target.value)}
                  />
                  <datalist id="task-categories-datalist">
                    <option value="Career" />
                    <option value="Health" />
                    <option value="Education" />
                    <option value="Finance" />
                    <option value="Family" />
                    <option value="Personal Growth" />
                  </datalist>
                </div>

                <div className="relative flex items-center">
                  <Clock className="absolute left-2.5 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
                  <input 
                    type="time"
                    className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl pl-8 pr-2 py-2 text-xs text-slate-300 outline-none"
                    value={completionTime}
                    onChange={(e) => setCompletionTime(e.target.value)}
                  />
                </div>

                <button type="submit" className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] text-xs font-bold px-4 rounded-xl transition-all">
                  Add to Inbox
                </button>
              </div>
            </div>
          </form>

          <div className="space-y-2">
            {filteredTasks.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-2xl">
                No active tasks logged under this category filter.
              </div>
            ) : (
              filteredTasks.map(t => (
                <div key={t.id} className="group relative flex flex-col md:flex-row md:items-center justify-between p-4 rounded-xl border border-slate-800/80 bg-[#0b1322]/80 gap-3 hover:border-slate-700 transition-all">
                  <div className="flex items-start gap-3 flex-1">
                    <input 
                      type="checkbox"
                      checked={t.completed}
                      onChange={() => toggleTask(t.id)}
                      className="mt-0.5 rounded border-slate-700 text-emerald-500 focus:ring-0 bg-[#080d16] h-4 w-4 shrink-0 cursor-pointer"
                    />
                    <div>
                      <span className={`text-xs font-medium ${t.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                        {t.title}
                      </span>
                      
                      <div className="flex flex-wrap items-center gap-2 mt-1.5 text-[10px] font-mono text-slate-500">
                        <span className="px-1.5 py-0.5 rounded bg-[#080d16] text-slate-400 border border-slate-900">
                          📁 {t.category}
                        </span>
                        <span className="flex items-center gap-1 text-slate-400">
                          <Clock className="w-2.5 h-2.5" /> Created at: {t.createdAt || 'Just Now'}
                        </span>
                        <span className={`capitalize font-bold ${
                          t.priority === 'high' ? 'text-rose-400' : t.priority === 'medium' ? 'text-amber-400' : 'text-slate-400'
                        }`}>
                          • {t.priority} Priority
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end md:self-center shrink-0">
                    <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg border text-[10px] font-mono ${
                      t.completed 
                        ? 'border-slate-800 bg-[#080d16]/30 text-slate-600' 
                        : t.notified 
                        ? 'border-rose-500/20 bg-rose-500/10 text-rose-400 animate-pulse'
                        : 'border-amber-500/20 bg-amber-500/5 text-amber-400'
                    }`}>
                      <Bell className={`w-3 h-3 ${t.notified && !t.completed ? 'fill-rose-400' : ''}`} />
                      <span>Complete Before: {t.completionTime}</span>
                    </div>

                    <button 
                      onClick={() => removeTask(t.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                      title="Permanently remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function HabitsLoopView({ theme, habits, setHabits, handleHabitToggle, triggerToast }) {
  const [newHabitTitle, setNewHabitTitle] = useState('');
  const [newHabitCat, setNewHabitCat] = useState('Health');
  const [newHabitTime, setNewHabitTime] = useState('08:00'); 

  const getTodayStr = () => new Date().toISOString().split('T')[0];

  const createHabit = (e) => {
    e.preventDefault();
    if (!newHabitTitle.trim()) return;
    
    const newH = {
      id: 'habit_' + Date.now(),
      name: newHabitTitle,
      frequency: 'Daily',
      streak: 0,
      completedDates: [],
      category: newHabitCat,
      targetTime: newHabitTime, 
      missedStreak: false,
      notified: false,
      notified10: false,
      notified5: false
    };
    
    setHabits(prev => [newH, ...prev]);
    triggerToast("Habit Loop Configured", `"${newHabitTitle}" scheduled for ${newHabitTime}`);
    setNewHabitTitle('');
    setNewHabitTime('08:00'); 
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-xl font-extrabold tracking-tight text-white">Habits Tracking Loop</h2>
        <p className="text-xs text-slate-400">Lock in behavioral patterns with scheduled time-bound reminders.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <form onSubmit={createHabit} className="p-4 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-3">
            <div className="flex flex-col gap-3">
              <input 
                type="text" 
                placeholder="Ex: Hydration Protocol, Review Ledger..."
                className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-3 py-2 text-xs outline-none text-slate-100"
                value={newHabitTitle}
                onChange={(e) => setNewHabitTitle(e.target.value)}
              />
              
              <div className="grid grid-cols-3 gap-2">
                <select 
                  className="bg-[#080d16] border dark:border-slate-800 rounded-xl px-2 py-2 text-xs text-slate-300"
                  value={newHabitCat}
                  onChange={(e) => setNewHabitCat(e.target.value)}
                >
                  <option value="Health">Health</option>
                  <option value="Career">Career</option>
                  <option value="Finance">Finance</option>
                  <option value="Personal Growth">Personal Growth</option>
                  <option value="Education">Education</option>
                  <option value="Family">Family</option>
                </select>
                
                <input 
                  type="time"
                  className="bg-[#080d16] border dark:border-slate-800 rounded-xl px-2 py-2 text-xs text-slate-300 outline-none"
                  value={newHabitTime}
                  onChange={(e) => setNewHabitTime(e.target.value)}
                />
                
                <button type="submit" className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] text-xs font-bold px-2 rounded-xl">
                  Register Habit
                </button>
              </div>
            </div>
          </form>

          <div className="space-y-3">
            {habits.length === 0 ? (
               <div className="py-12 text-center text-slate-500 text-xs">No habits logged. Formulate a routine above.</div>
            ) : (
              habits.map(h => {
                const isLogged = h.completedDates.includes(getTodayStr());
                return (
                  <div key={h.id} className="p-4 rounded-2xl border dark:border-slate-800 bg-[#0b1322] flex justify-between items-center">
                    <div>
                      <h4 className="font-bold text-xs text-slate-200">{h.name}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 font-bold uppercase tracking-wider font-mono">{h.category}</span>
                        <span className="text-[9px] text-emerald-500 font-mono font-bold">Target: {h.targetTime}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <span className="text-[9px] text-slate-500 font-mono block">Streak</span>
                        <p className="text-xs font-extrabold text-emerald-400 font-mono">{h.streak} DAYS</p>
                      </div>

                      <button 
                        onClick={() => handleHabitToggle(h.id)}
                        className={`px-4 py-1.5 text-xs font-bold uppercase rounded-lg border transition-all ${
                          isLogged 
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
                          : 'border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {isLogged ? 'Log Complete' : 'Log Target'}
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Cognitive Consistency</h3>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Time-bound habit tracking helps synchronize your physiological rhythm with productivity tasks. Ensure you stick to the target time to maximize dopamine stabilization.
          </p>
        </div>
      </div>
    </div>
  );
}

function GoalsRoadmapView({ theme, goals, setGoals, triggerToast }) {
  const [goalName, setGoalName] = useState('');
  const [goalCat, setGoalCat] = useState('Career');
  const [goalDate, setGoalDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [newMilestoneText, setNewMilestoneText] = useState({});
  const [newMilestoneDate, setNewMilestoneDate] = useState({});

  const handleCreateGoal = (e) => {
    e.preventDefault();
    if (!goalName.trim()) return;
    
    const newGoal = {
      id: 'goal_' + Date.now(),
      title: goalName,
      category: goalCat,
      targetDate: goalDate,
      progress: 0,
      milestones: []
    };

    setGoals(prev => [newGoal, ...prev]);
    triggerToast("Goal Created", `"${goalName}" added to roadmap.`);
    setGoalName('');
  };

  const addMilestone = (goal) => {
    const text = newMilestoneText[goal.id];
    const date = newMilestoneDate[goal.id] || new Date().toISOString().split('T')[0];
    
    if (!text) return;

    if (date > goal.targetDate) {
        triggerToast("Invalid Date", "Milestone cannot be set after the goal's target date.");
        return;
    }
    
    const newMilestone = {
        id: Date.now(), 
        text,
        date,
        completed: false
    };

    setGoals(prev => prev.map(g => {
      if (g.id === goal.id) {
        const updatedMilestones = [...g.milestones, newMilestone];
        return { ...g, milestones: updatedMilestones };
      }
      return g;
    }));

    setNewMilestoneText(prev => ({ ...prev, [goal.id]: '' }));
  };

  const toggleMilestone = (goalId, milestoneId) => {
    setGoals(prev => prev.map(g => {
      if (g.id === goalId) {
        const updatedMilestones = g.milestones.map(m => {
          if (m.id === milestoneId) return { ...m, completed: !m.completed };
          return m;
        });
        const completedCount = updatedMilestones.filter(m => m.completed).length;
        const total = updatedMilestones.length;
        const nextProgress = total > 0 ? Math.round((completedCount / total) * 100) : 0;
        return { ...g, milestones: updatedMilestones, progress: nextProgress };
      }
      return g;
    }));
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-xl font-extrabold tracking-tight text-white">Goal-to-Task Decomposition Matrix</h2>
        <p className="text-xs text-slate-400">Set high-level visions and build your own custom milestones.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <form onSubmit={handleCreateGoal} className="p-4 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-3">
            <div className="flex flex-col gap-3">
              <input 
                type="text" 
                placeholder="Ex: Learn concurrent Rust, Secure consultancy contract..."
                className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-3 py-2 text-xs outline-none text-slate-100"
                value={goalName}
                onChange={(e) => setGoalName(e.target.value)}
              />
              <div className="flex gap-2">
                <select 
                  className="bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300"
                  value={goalCat}
                  onChange={(e) => setGoalCat(e.target.value)}>
                  <option value="Career">Career</option>
                  <option value="Education">Education</option>
                  <option value="Finance">Finance</option>
                  <option value="Personal Growth">Personal Growth</option>
                  <option value="Health">Health</option>
                  <option value="Family">Family</option>
                </select>
                <input 
                  type="date"
                  className="bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 outline-none"
                  value={goalDate}
                  onChange={(e) => setGoalDate(e.target.value)}
                />
                <button 
                  type="submit" 
                  className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] text-xs font-bold px-4 rounded-xl"
                >
                  Create Goal
                </button>
              </div>
            </div>
          </form>

          <div className="space-y-4">
            {goals.length === 0 ? (
               <div className="py-12 text-center text-slate-500 text-xs">No active goals. Add a new vision above.</div>
            ) : (
                goals.map(g => (
                <div key={g.id} className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
                    <div className="flex justify-between items-start gap-3">
                        <div>
                            <h3 className="font-extrabold text-sm tracking-tight text-white">{g.title}</h3>
                            <div className="flex items-center gap-2 mt-1.5">
                                <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 font-bold uppercase tracking-wider font-mono">{g.category}</span>
                                <span className="text-[9px] text-slate-500 font-mono">Target Date: {g.targetDate}</span>
                            </div>
                        </div>
                        <span className="text-xs font-bold text-emerald-400 font-mono">{g.progress}% Complete</span>
                    </div>

                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full rounded-full transition-all duration-500" style={{ width: `${g.progress}%` }} />
                    </div>

                    <div className="space-y-3 pt-2 border-t dark:border-slate-800/60">
                        <div className="flex gap-2">
                             <input 
                                type="text"
                                placeholder="Add milestone..."
                                className="flex-1 bg-[#080d16] border dark:border-slate-800 rounded-lg px-2 py-1 text-[10px] text-slate-200"
                                value={newMilestoneText[g.id] || ''}
                                onChange={(e) => setNewMilestoneText({...newMilestoneText, [g.id]: e.target.value})}
                             />
                             <input 
                                type="date"
                                className="bg-[#080d16] border dark:border-slate-800 rounded-lg px-1 py-1 text-[10px] text-slate-400"
                                onChange={(e) => setNewMilestoneDate({...newMilestoneDate, [g.id]: e.target.value})}
                             />
                             <button onClick={() => addMilestone(g)} className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] px-3 rounded-lg font-bold">+</button>
                        </div>

                        {g.milestones.map((milestone) => (
                            <div key={milestone.id} className="flex items-center justify-between gap-3 p-2 rounded-lg bg-[#080d16]/50">
                                <div className="flex items-center gap-2">
                                    <button onClick={() => toggleMilestone(g.id, milestone.id)}>
                                        {milestone.completed ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <Circle className="w-4 h-4 text-slate-600 hover:text-slate-300" />}
                                    </button>
                                    <span className={`text-xs ${milestone.completed ? 'line-through text-slate-500' : 'text-slate-200'}`}>{milestone.text}</span>
                                </div>
                                <span className="text-[9px] text-slate-500 font-mono">{milestone.date}</span>
                            </div>
                        ))}
                    </div>
                </div>
                ))
            )}
          </div>
        </div>
        <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Cognitive Goal Analysis</h3>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            Deconstructed milestones can be integrated into daily task lists.
            Setting goals helps structure focus sessions and tracks work accuracy over time.
          </p>
        </div>
      </div>
    </div>
  );
}

function FocusAmbientView({ 
  theme, 
  focusTime, 
  setFocusTime, 
  focusRunning, 
  setFocusRunning, 
  focusCategory, 
  setFocusCategory 
}) {
  
  const getTodayKey = () => {
    const today = new Date();
    return `lifeflow_focus_sec_${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  };

  const storageKey = getTodayKey();

  const [dailySeconds, setDailySeconds] = useState(() => {
    const saved = localStorage.getItem(storageKey);
    return saved ? parseInt(saved, 10) : 0;
  });

  useEffect(() => {
    const lastTimeStr = localStorage.getItem('lifeflow_last_focus_time');
    const lastCategory = localStorage.getItem('lifeflow_last_focus_category');
    
    const lastTime = lastTimeStr ? parseInt(lastTimeStr, 10) : focusTime;

    const isFocusCategory = focusCategory !== 'Small Break' && focusCategory !== 'Long Break';
    const wasFocusCategory = lastCategory !== 'Small Break' && lastCategory !== 'Long Break';

    if (focusRunning && isFocusCategory && wasFocusCategory) {
      const delta = lastTime - focusTime;
      
      if (delta > 0 && delta < 1501) {
        setDailySeconds(prev => {
          const updatedSeconds = prev + delta;
          localStorage.setItem(storageKey, updatedSeconds.toString());
          return updatedSeconds;
        });
      }
    }

    localStorage.setItem('lifeflow_last_focus_time', focusTime.toString());
    localStorage.setItem('lifeflow_last_focus_category', focusCategory);
  }, [focusTime, focusRunning, focusCategory, storageKey]);

  const recordedMinutes = Math.floor(dailySeconds / 60);

  const formatTimeStr = () => {
    const mins = Math.floor(focusTime / 60);
    const secs = focusTime % 60;
    return `${mins < 10 ? '0' + mins : mins}:${secs < 10 ? '0' + secs : secs}`;
  };

  const timerPresets = [
    { label: 'Focus Time', seconds: 1500 }, 
    { label: 'Small Break', seconds: 300 },  
    { label: 'Long Break', seconds: 900 }    
  ];

  const getMaxTimeForCategory = () => {
    if (focusCategory === 'Small Break') return 300;
    if (focusCategory === 'Long Break') return 900;
    return 1500; 
  };

  const isPresetActive = (presetLabel) => {
    if (focusCategory === presetLabel) return true;
    if (presetLabel === 'Focus Time' && focusCategory === 'Coding') return true;
    return false;
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-xl font-extrabold tracking-tight text-white">Focus Ambient Room</h2>
        <p className="text-xs text-slate-400">Lock in long focus blocks without distractions</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-8 rounded-3xl border dark:border-slate-800 bg-[#0b1322] flex flex-col items-center justify-center space-y-6">
          <div className="flex gap-2">
            {timerPresets.map(preset => (
              <button 
                key={preset.label}
                onClick={() => {
                  setFocusCategory(preset.label);
                  setFocusTime(preset.seconds);
                  setFocusRunning(false); 
                }}
                className={`px-3 py-1 text-[9px] font-bold uppercase rounded-lg border tracking-wider transition-all ${
                  isPresetActive(preset.label) 
                    ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-400' 
                    : 'border-slate-800 text-slate-500'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>

          <div className="relative w-60 h-60 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="120" cy="120" r="100" fill="transparent" stroke="#080d16" strokeWidth="6" />
              <circle cx="120" cy="120" r="100" fill="transparent" stroke="#10b981" strokeWidth="6" 
                strokeDasharray={2 * Math.PI * 100}
                strokeDashoffset={2 * Math.PI * 100 * (1 - focusTime / getMaxTimeForCategory())}
                className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute text-center">
              <h1 className="text-4xl font-extrabold font-mono tracking-tighter text-slate-100">{formatTimeStr()}</h1>
              <p className="text-[9px] uppercase tracking-widest text-emerald-400 font-mono mt-1">
                {focusCategory !== 'Small Break' && focusCategory !== 'Long Break' ? 'Deep Work Active' : 'Rest Period'}
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <button 
              onClick={() => setFocusRunning(!focusRunning)}
              className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] text-xs font-bold uppercase tracking-wider px-6 py-2.5 rounded-xl flex items-center gap-1.5 shadow-lg shadow-emerald-500/10"
            >
               {focusRunning ? <Square className="w-3.5 h-3.5 fill-[#080d16]" /> : <Play className="w-3.5 h-3.5 fill-[#080d16]" />}
              {focusRunning ? 'Pause Session' : 'Initiate Session'}
            </button>
            <button 
              onClick={() => { 
                setFocusTime(getMaxTimeForCategory()); 
                setFocusRunning(false); 
              }}
              className="bg-[#080d16] hover:bg-slate-900 border dark:border-slate-800 text-slate-300 text-xs font-bold uppercase tracking-wider px-6 py-2.5 rounded-xl"
            >
              Reset
            </button>
          </div>
        </div>

        <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">Session Analytics</h3>
          
          <div className="p-4 rounded-xl bg-[#080d16] border dark:border-slate-800/80 text-center flex flex-col justify-center min-h-[120px]">
            <span className="text-[9px] text-slate-500 font-mono uppercase block">Recorded Focus Today</span>
            <h4 className="text-2xl font-extrabold text-emerald-400 mt-2 font-mono tracking-tight">
              {recordedMinutes} <span className="text-sm text-slate-500 font-sans font-bold">Min</span>
            </h4>
            <p className="text-[10px] text-slate-400 leading-normal mt-2">
              Active running minutes tracked across focus blocks. Breaks excluded.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TaskCard({ task, onToggle }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className={`p-3.5 rounded-xl border transition-all ${
      task.completed 
        ? 'opacity-60 bg-[#0b1322]/40 border-slate-900/60' 
        : 'bg-[#0c1220] border-slate-800/80 hover:border-slate-700'
    }`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <button onClick={() => onToggle(task.id)} className="mt-0.5">
            {task.completed ? (
               <CheckCircle className="w-4 h-4 text-emerald-400 fill-emerald-500/10" />
            ) : (
              <Circle className="w-4 h-4 text-slate-500 hover:text-emerald-400" />
            )}
          </button>
          <div>
            <h4 className={`text-xs font-bold leading-normal text-slate-200 ${task.completed ? 'line-through text-slate-500 font-normal' : ''}`}>
              {task.title}
            </h4>
            <div className="flex items-center gap-2 mt-1.5 font-mono text-[9px] text-slate-500">
              <span className="text-emerald-500 uppercase tracking-wider font-bold">{task.category}</span>
              <span>•</span>
              <span>{task.time || '12:00'}</span>
              <span>•</span>
              <span className={`font-bold ${
                task.priority === 'high' ? 'text-rose-500' : 'text-slate-400'
              }`}>
                {task.priority.toUpperCase()}
              </span>
            </div>
          </div>
        </div>

        {task.subtasks && task.subtasks.length > 0 && (
          <button 
            onClick={() => setExpanded(!expanded)}
            className="p-1 rounded text-slate-500 hover:text-white"
          >
            <ChevronDown className={`w-3.5 h-3.5 transform transition-transform ${expanded ? 'rotate-180' : ''}`} />
          </button>
        )}
      </div>

      {expanded && task.subtasks && task.subtasks.length > 0 && (
        <div className="mt-3.5 pl-7 border-t dark:border-slate-850 pt-2.5 space-y-2 animate-fadeIn">
          {task.subtasks.map((st, idx) => (
            <div key={idx} className="flex items-center gap-2.5 text-xs text-slate-400">
              <Check className="w-3 h-3 text-emerald-400" />
              <span>{st}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CommandPalette({ onClose, onSelectView }) {
  const [paletteSearch, setPaletteSearch] = useState('');
  const commands = [
    { label: 'Go to Dashboard View', view: 'dashboard' },
    { label: 'Go to My Day View', view: 'myday' },
    { label: 'Manage All Tasks', view: 'tasks' },
    { label: 'Analyze Performance Analytics', view: 'analytics' },
    { label: 'Configure Integration Settings', view: 'settings' }
  ];
  const matched = commands.filter(cmd => 
    cmd.label.toLowerCase().includes(paletteSearch.toLowerCase())
  );
  return (
    <div className="fixed inset-0 z-50 bg-[#080d16]/80 backdrop-blur-sm flex items-start justify-center p-4 pt-20">
      <div className="max-w-lg w-full p-4 rounded-2xl bg-[#0b1322] border border-slate-800 shadow-2xl space-y-3">
        <div className="flex items-center gap-2 bg-[#080d16] p-2 rounded-xl border border-slate-800">
          <Search className="w-4 h-4 text-slate-500" />
          <input 
            type="text" 
            placeholder="Type a directory path or layout view..."
            className="w-full bg-transparent border-none outline-none text-xs text-slate-200"
            value={paletteSearch}
            onChange={(e) => setPaletteSearch(e.target.value)}
            autoFocus
          />
        </div>

        <div className="space-y-1">
          {matched.map((cmd, idx) => (
           <button 
              key={idx}
              onClick={() => onSelectView(cmd.view)}
              className="w-full p-2.5 rounded-xl hover:bg-[#080d16] text-xs text-left text-slate-300 hover:text-white transition-all flex justify-between items-center"
            >
              <span>{cmd.label}</span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
            </button>
          ))}
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono px-1">
          <span>Press ESC to exit</span>
          <button onClick={onClose} className="hover:text-white">CLOSE PALETTE</button>
        </div>
      </div>
    </div>
  );
}

function OnboardingOverlay({ theme, onClose }) {
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [answers, setAnswers] = useState({
    archetype: 'student',
    stars: 'deep habits',
    planningStyle: 'time blocks'
  });
  return (
    <div className="fixed inset-0 z-50 bg-[#080d16]/95 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full p-6 rounded-2xl bg-[#0b1322] border border-slate-800 shadow-2xl space-y-5 animate-fadeIn">
        <div className="flex justify-between items-center">
          <div className="flex gap-1.5">
            {[1, 2, 3].map(stepNum => (
              <span key={stepNum} className={`w-6 h-1 rounded-full ${
                 onboardingStep >= stepNum ? 'bg-emerald-500' : 'bg-slate-800'
              }`} />
            ))}
          </div>
          <span className="text-[9px] text-emerald-400 font-mono">STEP {onboardingStep} OF 3</span>
        </div>

        {onboardingStep === 1 && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-slate-100">Select your workspace style</h3>
            <p className="text-xs text-slate-400 leading-normal">This aligns task generation templates and prioritization defaults.</p>
            
            <div className="grid grid-cols-2 gap-2">
              {['student', 'developer', 'creator', 'founder'].map(arch => (
                <button 
                 key={arch}
                  onClick={() => setAnswers({ ...answers, archetype: arch })}
                  className={`p-3 rounded-xl border text-left capitalize text-xs font-semibold ${
                    answers.archetype === arch ? 'border-emerald-500/25 bg-emerald-500/10 text-emerald-400' : 'border-slate-800 bg-[#080d16]'
                  }`}
                >
                  {arch}
                </button>
              ))}
            </div>
             
            <button onClick={() => setOnboardingStep(2)} className="w-full bg-emerald-500 hover:bg-emerald-600 text-[#080d16] font-bold text-xs py-2 rounded-xl">Next Step</button>
          </div>
        )}

        {onboardingStep === 2 && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-slate-100">Establish your North Star goal</h3>
             <p className="text-xs text-slate-400 leading-normal">Select the system focus coordinate you are optimization for today.</p>
            
            <div className="space-y-2">
              {['deep habits', 'career milestones', 'health markers', 'theory study'].map(g => (
                <button 
                  key={g}
                  onClick={() => setAnswers({ ...answers, stars: g })}
                  className={`w-full p-3 rounded-xl border text-left capitalize text-xs font-semibold ${
                    answers.stars === g ? 'border-emerald-500/25 bg-emerald-500/10 text-emerald-400' : 'border-slate-800 bg-[#080d16]'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
             
            <button onClick={() => setOnboardingStep(3)} className="w-full bg-emerald-500 hover:bg-emerald-600 text-[#080d16] font-bold text-xs py-2 rounded-xl">Next Step</button>
          </div>
        )}

        {onboardingStep === 3 && (
          <div className="space-y-4">
            <h3 className="text-sm font-extrabold text-slate-100">Calibrate energy cycles</h3>
             <p className="text-xs text-slate-400 leading-normal">Align scheduled periods with actual cognitive peak cycles.</p>
            
            <div className="space-y-2">
              {['morning peak hours', 'balanced daylight flow', 'late night blocks'].map(p => (
                <button 
                  key={p}
                  onClick={() => setAnswers({ ...answers, planningStyle: p })}
                  className={`p-3 rounded-xl border text-left capitalize text-xs font-semibold ${
                    answers.planningStyle === p ? 'border-emerald-500/25 bg-emerald-500/10 text-emerald-400' : 'border-slate-800 bg-[#080d16]'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
             
            <button onClick={onClose} className="w-full bg-emerald-500 hover:bg-emerald-600 text-[#080d16] font-bold text-xs py-2 rounded-xl">Complete Calibration</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/dashboard" element={<LifeFlow />} />
        <Route path="*" element={<Navigate to="/auth" />} />
      </Routes>
    </Router>
  );
}