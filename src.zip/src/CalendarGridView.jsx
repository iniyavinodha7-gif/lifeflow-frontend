import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react'; // Ensure these are imported

export default function CalendarGridView({ theme, tasks, setTasks, triggerToast }) {
  const [selectedDate, setSelectedDate] = useState(null);
  
  // New State for Calendar Navigation
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Task Form State
  const [taskTitle, setTaskTitle] = useState('');
  const [taskPriority, setTaskPriority] = useState('medium');
  const [taskCategory, setTaskCategory] = useState('');
  const [taskTime, setTaskTime] = useState('12:00');

  // Actual Today for highlighting
  const today = new Date().toISOString().split('T')[0];
  
  // Dynamic Date Calculations
  const viewingYear = currentDate.getFullYear();
  const viewingMonth = currentDate.getMonth(); // 0-11
  
  // Format current month prefix (e.g., "2026-06-")
  const currentMonthPrefix = `${viewingYear}-${(viewingMonth + 1).toString().padStart(2, '0')}-`;
  
  // Get Month Name for Header
  const monthName = currentDate.toLocaleString('default', { month: 'long' });
  
  // Calculate exactly how many days are in this specific month/year
  const daysInMonth = new Date(viewingYear, viewingMonth + 1, 0).getDate();
  const daysArray = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  
  // Calculate which day of the week the 1st falls on to pad the grid (0 = Sun, 1 = Mon)
  const firstDayOfMonth = new Date(viewingYear, viewingMonth, 1).getDay();
  const startingEmptySlots = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1; // Adjusting for Monday start
  const blanks = Array.from({ length: startingEmptySlots }, (_, i) => i);

  const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  // Navigation Handlers
  const handlePrevMonth = () => {
    setCurrentDate(new Date(viewingYear, viewingMonth - 1, 1));
    setSelectedDate(null); // Clear selection on month change
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(viewingYear, viewingMonth + 1, 1));
    setSelectedDate(null);
  };

  const handleAddTask = (e) => {
    e.preventDefault();
    if (!taskTitle.trim() || !taskCategory.trim()) {
      triggerToast("Missing Fields", "Please provide a task name and category.", "Error");
      return;
    }

    const timeInstance = new Date();
    const cleanCreationTime = timeInstance.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit', 
      hour12: true 
    });

    const newTask = {
      id: 'task_' + Date.now(),
      title: taskTitle,
      date: selectedDate,
      time: taskTime,
      completionTime: taskTime, 
      createdAt: cleanCreationTime,
      priority: taskPriority,
      category: taskCategory.trim(),
      completed: false,
      notified: false,
      subtasks: []
    };

    setTasks(prev => [newTask, ...prev]);
    triggerToast("Task Scheduled", `"${taskTitle}" locked for ${selectedDate}`);
    
    setTaskTitle('');
    setTaskCategory('');
    setTaskTime('12:00');
    setTaskPriority('medium');
    setSelectedDate(null);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header & Navigation */}
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-xl font-extrabold tracking-tight text-white">Calendar Planner Matrix</h2>
          <p className="text-xs text-slate-400">Select a date to schedule tasks directly into your pipeline</p>
        </div>
        
        {/* Month/Year Navigation Controls */}
        <div className="flex items-center gap-4 bg-[#0b1322] border border-slate-800 rounded-xl p-1.5 shadow-lg">
          <button 
            onClick={handlePrevMonth}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="w-32 text-center">
            <span className="text-sm font-bold text-slate-100 uppercase tracking-widest font-mono">
              {monthName} {viewingYear}
            </span>
          </div>
          <button 
            onClick={handleNextMonth}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Dynamic Task Creation Form for Selected Date */}
      {selectedDate && (
        <form onSubmit={handleAddTask} className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/[0.02] space-y-4 animate-fadeIn">
          <div className="flex justify-between items-center border-b border-emerald-500/20 pb-2 mb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">
              Schedule for: {selectedDate}
            </h3>
            <button 
              type="button" 
              onClick={() => setSelectedDate(null)}
              className="text-[10px] text-slate-400 hover:text-white"
            >
              CANCEL
            </button>
          </div>

          <div className="flex flex-col gap-3">
            <input 
              type="text" 
              placeholder="What objective needs to be completed on this day?"
              className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-3 py-2.5 text-xs outline-none text-slate-100 placeholder:text-slate-600 focus:border-emerald-500/50 transition-colors"
              value={taskTitle}
              onChange={(e) => setTaskTitle(e.target.value)}
            />
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
              <select 
                className="bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 outline-none"
                value={taskPriority}
                onChange={(e) => setTaskPriority(e.target.value)}
              >
                <option value="high">🛑 High Priority</option>
                <option value="medium">⚡ Medium Priority</option>
                <option value="low">☕ Low Priority</option>
              </select>
              
              <input 
                type="text"
                placeholder="Custom Category (e.g., Client Work)"
                className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50 transition-colors"
                value={taskCategory}
                onChange={(e) => setTaskCategory(e.target.value)}
                required
              />

              <input 
                type="time"
                className="w-full bg-[#080d16] border dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-300 outline-none"
                value={taskTime}
                onChange={(e) => setTaskTime(e.target.value)}
              />

              <button type="submit" className="bg-emerald-500 hover:bg-emerald-600 text-[#080d16] text-xs font-bold px-4 rounded-xl transition-all shadow-lg shadow-emerald-500/20">
                Lock Task
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="p-5 rounded-2xl border dark:border-slate-800 bg-[#0b1322] space-y-4">
        
        {/* Calendar days mapping */}
        <div className="grid grid-cols-7 gap-2 text-center mb-2">
          {weekdays.map(wd => (
            <span key={wd} className="text-[10px] font-bold uppercase tracking-wider text-slate-500 font-mono">{wd}</span>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2 min-h-96">
          {/* Render empty slots for correct day alignment */}
          {blanks.map(blank => (
            <div key={`blank-${blank}`} className="p-2.5 rounded-xl min-h-[90px] bg-transparent"></div>
          ))}

          {/* Render actual days */}
          {daysArray.map(dayNum => {
            const formattedDate = `${currentMonthPrefix}${dayNum < 10 ? '0' + dayNum : dayNum}`;
            const matchedTasks = tasks.filter(t => t.date === formattedDate);
            const isSelected = selectedDate === formattedDate;

            return (
              <div 
                key={dayNum}
                onClick={() => setSelectedDate(formattedDate)}
                className={`p-2.5 rounded-xl border min-h-[90px] flex flex-col justify-between transition-all cursor-pointer hover:border-emerald-500/50 ${
                  isSelected
                    ? 'border-emerald-500 ring-1 ring-emerald-500/50 bg-[#0c1220]'
                    : formattedDate === today 
                    ? 'border-emerald-500/30 bg-emerald-500/[0.05] text-slate-100' 
                    : 'border-slate-800/60 bg-[#080d16]/80'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className={`text-[10px] font-bold font-mono ${isSelected || formattedDate === today ? 'text-emerald-400' : ''}`}>
                    {dayNum}
                  </span>
                  {matchedTasks.length > 0 && <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />}
                </div>

                <div className="space-y-1 mt-2">
                  {matchedTasks.slice(0, 2).map(task => (
                    <p key={task.id} className="text-[8px] font-semibold truncate bg-slate-800 px-1 py-0.5 rounded border border-slate-700 max-w-[90px] text-slate-300">
                      {task.title}
                    </p>
                  ))}
                  {matchedTasks.length > 2 && (
                    <p className="text-[7px] text-slate-500 font-bold font-mono">+{matchedTasks.length - 2} MORE</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}